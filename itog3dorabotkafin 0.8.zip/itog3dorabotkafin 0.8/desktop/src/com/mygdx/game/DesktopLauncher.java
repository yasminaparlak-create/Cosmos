package com.mygdx.game;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import com.badlogic.gdx.physics.box2d.Box2D;


// Please note that on macOS your application needs to be started with the -XstartOnFirstThread JVM argument
public class DesktopLauncher {
	public static void main (String[] arg) {
        Box2D.init();
        Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
		config.setForegroundFPS(60);
		config.setTitle("Cosmos");
        config.setWindowedMode(GameSettings.SCREEN_WIDTH / 2 , GameSettings.SCREEN_HEIGHT / 2);
        new Lwjgl3Application(new MyGdxGame(), config);
	}
}
