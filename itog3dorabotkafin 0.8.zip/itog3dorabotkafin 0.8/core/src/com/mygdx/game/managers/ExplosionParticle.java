package com.mygdx.game.managers;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class ExplosionParticle {
    public float x, y;
    public float vx, vy;

    public float life = 0f;
    public float size;
    public Color color;
    public TextureRegion texture;

    public ExplosionParticle(TextureRegion texture) {
        this.texture = texture;
        this.color = new Color();
    }

    public void reset(float startX, float startY) {
        this.x = startX;
        this.y = startY;

        float angle = (float) (Math.random() * 2 * Math.PI);
        float speed = 50f + (float) (Math.random() * 150f);

        this.vx = (float) (Math.cos(angle) * speed);
        this.vy = (float) (Math.sin(angle) * speed);

        this.life = 1.0f;
        this.size = 2f + (float) (Math.random() * 6f);

        float r = 1.0f;
        float g = (float) (0.4f + Math.random() * 0.6f);
        float b = (float) (Math.random() * 0.2f);
        this.color.set(r, g, b, 1f);
    }

    public void update(float delta) {
        x += vx * delta;
        y += vy * delta;
        vx *= 0.95f;
        vy *= 0.95f;
        life -= delta * 1.6f;
    }

    public void draw(SpriteBatch batch) {
        if (life > 0) {
            batch.setColor(color.r, color.g, color.b, life);
            batch.draw(texture, x - size / 2, y - size / 2, size, size);
            batch.setColor(Color.WHITE);
        }
    }

}