package com.mygdx.game.managers;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;

public class ExplosionManager {


    private final Array<ExplosionParticle> particles;
    private Texture particleSourceTexture;

    public ExplosionManager(TextureRegion textureRegion) {
        this.particles = new Array<>();

        if (textureRegion != null) {

            this.particleSourceTexture = textureRegion.getTexture();

            for (int i = 0; i < 60; i++) {
                particles.add(new ExplosionParticle(textureRegion));
            }
        } else {
            this.particleSourceTexture = null;
        }
    }

    public void spawnExplosion(float x, float y, int count) {
        for (int i = 0; i < count; i++) {

            ExplosionParticle p = particles.get((int)(Math.random() * particles.size));
            p.reset(x, y);
        }
    }

    public void update(float delta) {
        for (ExplosionParticle p : particles) {
            p.update(delta);
        }
    }

    public void draw(SpriteBatch batch) {
        for (ExplosionParticle p : particles) {

            if (p.life > 0) {
                p.draw(batch);
            }
        }
    }

    public void clear() {
        for (ExplosionParticle p : particles) {
            p.life = 0;
        }
    }

    public void dispose() {

        if (particleSourceTexture != null) {
            particleSourceTexture.dispose();
            particleSourceTexture = null;
        }
        clear();
    }
}