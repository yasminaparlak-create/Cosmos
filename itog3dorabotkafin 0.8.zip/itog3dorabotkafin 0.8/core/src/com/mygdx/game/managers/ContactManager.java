package com.mygdx.game.managers;

import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.mygdx.game.GameSettings;
import com.mygdx.game.objects.*;

public class ContactManager implements ContactListener {

    @Override
    public void beginContact(Contact contact) {
        Fixture fixA = contact.getFixtureA();
        Fixture fixB = contact.getFixtureB();

        Object objA = fixA.getUserData();
        Object objB = fixB.getUserData();

        if (objA == null || objB == null) {
            return;
        }

        int bitsA = fixA.getFilterData().categoryBits;
        int bitsB = fixB.getFilterData().categoryBits;

        // ===== 1. BULLET vs TRASH =====
        if (check(bitsA, bitsB, GameSettings.BULLET_BIT, GameSettings.TRASH_BIT)) {
            BulletObject bullet = null;
            TrashObject trash = null;

            if (objA instanceof BulletObject) bullet = (BulletObject) objA;
            else if (objB instanceof BulletObject) bullet = (BulletObject) objB;

            if (objA instanceof TrashObject) trash = (TrashObject) objA;
            else if (objB instanceof TrashObject) trash = (TrashObject) objB;

            if (bullet != null && trash != null) {
                trash.setDestroyedByBullet(true);
                bullet.hit();
                trash.hit();
                bullet.pendingRemoval = true;
            }
        }

        // ===== 2. SHIP vs TRASH =====
        if (check(bitsA, bitsB, GameSettings.SHIP_BIT, GameSettings.TRASH_BIT)) {
            ShipObject ship = null;
            TrashObject trash = null;

            if (objA instanceof ShipObject) ship = (ShipObject) objA;
            else if (objB instanceof ShipObject) ship = (ShipObject) objB;

            if (objA instanceof TrashObject) trash = (TrashObject) objA;
            else if (objB instanceof TrashObject) trash = (TrashObject) objB;

            if (ship != null && trash != null && !trash.isDestroyedByBullet()) {
                ship.hit();
                trash.hit();
            }
        }

        // ===== 3. SHIP vs LOOT =====
        if (check(bitsA, bitsB, GameSettings.SHIP_BIT, GameSettings.LOOT_BIT)) {
            ShipObject ship = null;
            LootObject loot = null;

            if (objA instanceof ShipObject) ship = (ShipObject) objA;
            else if (objB instanceof ShipObject) ship = (ShipObject) objB;

            if (objA instanceof LootObject) loot = (LootObject) objA;
            else if (objB instanceof LootObject) loot = (LootObject) objB;

            if (ship != null && loot != null && !loot.isCollected()) {
                ship.applyLoot(loot.type);
                loot.collect();
            }
        }
    }

    @Override
    public void endContact(Contact contact) {
    }

    @Override
    public void preSolve(Contact contact, Manifold oldManifold) {

    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {

    }
    private boolean check(int a, int b, int type1, int type2) {
        return (a == type1 && b == type2) || (a == type2 && b == type1);
    }
}