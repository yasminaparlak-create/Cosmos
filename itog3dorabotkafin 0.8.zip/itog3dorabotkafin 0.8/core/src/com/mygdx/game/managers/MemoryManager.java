package com.mygdx.game.managers;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.utils.Json;
import java.util.ArrayList;

public class MemoryManager {
    private static final Preferences preferences = Gdx.app.getPreferences("User saves");
    private static final String DEFAULT_SHIP_PATH = "textures/ship1.png";

    public static void saveSoundSettings(boolean isOn) {
        preferences.putBoolean("isSoundOn", isOn);
        preferences.flush();
    }

    public static boolean loadIsSoundOn() {
        return preferences.getBoolean("isSoundOn", true);
    }

    public static void saveMusicSettings(boolean isOn) {
        preferences.putBoolean("isMusicOn", isOn);
        preferences.flush();
    }

    public static boolean loadIsMusicOn() {
        return preferences.getBoolean("isMusicOn", true);
    }

    public static void saveTableOfRecords(ArrayList<Integer> table) {
        Json json = new Json();
        String tableInString = json.toJson(table);
        preferences.putString("recordTable", tableInString);
        preferences.flush();
    }

    @SuppressWarnings("unchecked")
    public static ArrayList<Integer> loadRecordsTable() {

        if (!preferences.contains("recordTable")) {
            return new ArrayList<>();
        }

        try {
            String scores = preferences.getString("recordTable");
            Json json = new Json();
            ArrayList<Integer> table = json.fromJson(ArrayList.class, scores);

            if (table == null) return new ArrayList<>();
            return table;
        } catch (Exception e) {
            Gdx.app.error("MemoryManager", "Ошибка загрузки рекордов", e);
            return new ArrayList<>();
        }
    }

    public static void saveShipImagePath(String path) {
        preferences.putString("shipImagePath", path);
        preferences.flush();
    }

    public static String loadShipImagePath() {
        return preferences.getString("shipImagePath", DEFAULT_SHIP_PATH);
    }

    public static void saveSelectedSkinIndex(int index) {
        preferences.putInteger("selectedSkinIndex", index);
        preferences.flush();
    }

    public static int loadSelectedSkinIndex() {

        return preferences.getInteger("selectedSkinIndex", 2);
    }


    public static void clearRecords() {
        preferences.remove("recordTable");
        preferences.flush();
    }
}