package com.mygdx.game.managers;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.mygdx.game.GameResources;

public class AudioManager {

    public boolean isSoundOn;
    public boolean isMusicOn;
    public Sound explosionSound;
    public Music backgroundMusic;
    public Sound shootSound;
    public Sound explosionSoundSH;
    public Sound BtnClick;

    public AudioManager() {
        backgroundMusic = Gdx.audio.newMusic(Gdx.files.internal(GameResources.BACKGROUND_MUSIC_PATH));
        shootSound = Gdx.audio.newSound(Gdx.files.internal(GameResources.SHOOT_SOUND_PATH));
        explosionSound = Gdx.audio.newSound(Gdx.files.internal(GameResources.DESTROY_SOUND_PATH));
        explosionSoundSH = Gdx.audio.newSound(Gdx.files.internal(GameResources.DESTROY_SHIP_SOUND_PATH));
        BtnClick = Gdx.audio.newSound(Gdx.files.internal(GameResources.CLICK_SOUND_PATH));

        backgroundMusic.setVolume(0.2f);
        backgroundMusic.setLooping(true);

        updateSoundFlag();
        updateMusicFlag();
    }

    public void updateSoundFlag() {
        isSoundOn = MemoryManager.loadIsSoundOn();
    }

    public void updateMusicFlag() {
        isMusicOn = MemoryManager.loadIsMusicOn();
        if (isMusicOn) {
            backgroundMusic.play();
        } else {
            backgroundMusic.stop();
        }
    }


    public void toggleMusic() {
        isMusicOn = !isMusicOn;
        MemoryManager.saveMusicSettings(isMusicOn);

        if (isMusicOn) {
            if (backgroundMusic != null && !backgroundMusic.isPlaying()) {
                backgroundMusic.play();
                backgroundMusic.setLooping(true);
            }
        } else {
            if (backgroundMusic != null) {
                backgroundMusic.pause();
            }
        }
    }

    public void dispose() {

        if (BtnClick != null) BtnClick.dispose();
        if (shootSound != null) shootSound.dispose();
        if (explosionSound != null) explosionSound.dispose();
        if (explosionSoundSH != null) explosionSoundSH.dispose();


        if (backgroundMusic != null) {
            backgroundMusic.stop();
            backgroundMusic.dispose();
        }
    }
}