package com.mygdx.game.objects;

public enum LootType {
    RAPID_FIRE,    // индекс 0
    SHIELD,        // индекс 1
    EXTRA_LIFE,    // индекс 2
    SCORE_BOOST    // индекс 3
}