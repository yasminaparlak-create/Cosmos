package com.mygdx.game.objects;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.physics.box2d.Filter;
import com.badlogic.gdx.physics.box2d.World;
import com.mygdx.game.GameSettings;

public class LootObject extends GameObject {
    public LootType type;
    public boolean collected = false;


    public LootObject(int x, int y, LootType type, String texturePath, World world) {

        super(texturePath, x, y, GameSettings.LOOT_WIDTH, GameSettings.LOOT_HEIGHT, GameSettings.LOOT_BIT, world);

        this.type = type;

        body.setGravityScale(0.3f);
        body.setLinearVelocity(0, -GameSettings.LOOT_FALL_SPEED);
        body.setAngularVelocity(0);

        Filter filter = new Filter();
        filter.categoryBits = GameSettings.LOOT_BIT;
        filter.maskBits = GameSettings.SHIP_BIT;
        body.getFixtureList().get(0).setFilterData(filter);
    }
    public void collect() {
        collected = true;
        alive = false;
    }
    public boolean isCollected() { return collected; }

    public boolean shouldBeRemoved() {
        return collected || !alive || getY() < -50;
    }

    @Override
    public void draw(SpriteBatch batch) {
        if (collected) return;
        float alpha = 0.7f + (float)(Math.sin(System.currentTimeMillis() * 0.005f) * 0.7f);
        batch.setColor(1, 1, 1, alpha);
        super.draw(batch);
        batch.setColor(1, 1, 1, 1);
    }
}