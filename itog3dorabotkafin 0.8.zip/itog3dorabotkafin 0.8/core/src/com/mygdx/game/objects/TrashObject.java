package com.mygdx.game.objects;

import com.badlogic.gdx.physics.box2d.World;
import com.mygdx.game.GameSettings;

public class TrashObject extends GameObject {
    private boolean destroyedByBullet = false;

    public TrashObject(int width, int height, String texturePath, World world, float speed, float xSpeed) {

        super(texturePath,
                (int)(Math.random() * (GameSettings.SCREEN_WIDTH - width)),
                GameSettings.SCREEN_HEIGHT + 100,
                width, height,
                GameSettings.TRASH_BIT, world);

        body.setBullet(true);

        body.setGravityScale(0f);

        body.setLinearVelocity(xSpeed / GameSettings.PPM, -speed / GameSettings.PPM);

        float spinSpeed = (float) ((Math.random() - 0.5) * 6f);
        body.setAngularVelocity(spinSpeed);

        body.setAngularDamping(1.0f);
    }

    public void setDestroyedByBullet(boolean value) {
        this.destroyedByBullet = value;
    }

    public boolean isDestroyedByBullet() {
        return destroyedByBullet;
    }
}
