package com.mygdx.game.objects;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.TimeUtils;
import com.mygdx.game.GameResources;
import com.mygdx.game.GameSettings;
import com.mygdx.game.MyGdxGame;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class ShipObject extends GameObject {

    public float invincibilityTimer = 0f;
    public int livesLeft = 3;
    public long lastShotTime;

    // Баффы
    public float rapidFireTimer = 0;
    public boolean hasShield = false;
    public int scoreMultiplier = 1;
    public float scoreBoostTimer = 0;
    private TextureRegion shieldRegion;

    public ShipObject(int x, int y, int width, int height, String texturePath, World world) {
        super(texturePath, x, y, width, height, GameSettings.SHIP_BIT, world);
        body.setFixedRotation(true);
        body.setLinearDamping(8f);

        if (GameResources.shieldEffectTexture != null) {
            shieldRegion = new TextureRegion(GameResources.shieldEffectTexture);
        }
    }
    public void move(Vector3 touch) {
        float targetX = touch.x / GameSettings.PPM;
        float targetY = touch.y / GameSettings.PPM;

        Vector2 pos = body.getPosition();
        float diffX = targetX - pos.x;
        float diffY = targetY - pos.y;

        float velX = diffX * 12f;
        float velY = diffY * 12f;

        float maxSpeed = 18f;
        if (velX > maxSpeed) velX = maxSpeed;
        if (velX < -maxSpeed) velX = -maxSpeed;
        if (velY > maxSpeed) velY = maxSpeed;
        if (velY < -maxSpeed) velY = -maxSpeed;

        body.setLinearVelocity(velX, velY);
    }
    public void constrainToScreen() {
        float halfW = width / 2f / GameSettings.PPM;
        float halfH = height / 2f / GameSettings.PPM;

        float maxX = (GameSettings.SCREEN_WIDTH / GameSettings.PPM) - halfW;
        float maxY = (GameSettings.SCREEN_HEIGHT / GameSettings.PPM) - halfH;

        Vector2 pos = body.getPosition();
        boolean clamped = false;
        float newX = pos.x;
        float newY = pos.y;

        if (newX < halfW) { newX = halfW; clamped = true; }
        if (newX > maxX) { newX = maxX; clamped = true; }
        if (newY < halfH) { newY = halfH; clamped = true; }
        if (newY > maxY) { newY = maxY; clamped = true; }

        if (clamped) {
            body.setTransform(newX, newY, 0);
            body.setLinearVelocity(0, 0);
        }
    }
    @Override
    public void hit() {
        if (invincibilityTimer > 0) return;

        if (hasShield) {
            hasShield = false;
            invincibilityTimer = 0.5f;
            return;
        }

        livesLeft--;
        invincibilityTimer = 1.5f;

        if (livesLeft <= 0) {
            alive = false;
        }

        if (MyGdxGame.audioManager.isSoundOn) {
            MyGdxGame.audioManager.explosionSoundSH.play();
        }
    }

    @Override
    public void draw(SpriteBatch batch) {
        if (invincibilityTimer > 0) {
            this.setColor(1f, 1f, 1f, ((int)(invincibilityTimer * 10) % 2 == 0) ? 0.2f : 1f);
        } else {
            this.setColor(1f, 1f, 1f, 1f);
        }

        super.draw(batch);


        if (hasShield && shieldRegion != null) {
            float pulse = (float) Math.sin(System.currentTimeMillis() * 0.005f) * 0.2f + 0.6f;

            batch.setColor(0.4f, 0.8f, 1f, pulse * 0.5f);

            float centerX = getX();
            float centerY = getY();

            float shieldSize = width * 1.5f;

            batch.draw(shieldRegion,
                    centerX - shieldSize / 2f,  // X левого нижнего угла
                    centerY - shieldSize / 2f,  // Y левого нижнего угла
                    shieldSize / 2f,            // Центр вращения X
                    shieldSize / 2f,            // Центр вращения Y
                    shieldSize,                 // Ширина
                    shieldSize,                 // Высота
                    1f, 1f,
                    getRotation()               // Поворот как у корабля
            );

            batch.setColor(1f, 1f, 1f, 1f);
        }

        this.setColor(1f, 1f, 1f, 1f);
    }

    public void update(float delta) {

        if (invincibilityTimer > 0) {
            invincibilityTimer -= delta;
            if (invincibilityTimer < 0) invincibilityTimer = 0;
        }

        if (rapidFireTimer > 0) {
            rapidFireTimer -= delta;
            if (rapidFireTimer < 0) rapidFireTimer = 0;
        }

        if (scoreBoostTimer > 0) {
            scoreBoostTimer -= delta;
            if (scoreBoostTimer <= 0) {
                scoreBoostTimer = 0;
                scoreMultiplier = 1;
            }
        }
    }
    public boolean needToShoot() {

        float cooldown = GameSettings.SHOOTING_COOL_DOWN;

        if (TimeUtils.millis() - lastShotTime >= cooldown) {
            lastShotTime = TimeUtils.millis();
            return true;
        }
        return false;
    }

    public void applyLoot(LootType type) {
        switch (type) {
            case RAPID_FIRE:
                rapidFireTimer = 10f;
                break;
            case SHIELD:
                hasShield = true;
                break;
            case EXTRA_LIFE:
                livesLeft = Math.min(livesLeft + 1, 3);
                break;
            case SCORE_BOOST:
                scoreMultiplier = 2;
                scoreBoostTimer = 15f;
                break;
        }
    }
    public int getLiveLeft() { return livesLeft; }

    public void dispose() {
        shieldRegion = null;
    }
}