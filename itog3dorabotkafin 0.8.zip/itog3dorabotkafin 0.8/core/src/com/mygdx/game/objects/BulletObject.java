package com.mygdx.game.objects;

import com.badlogic.gdx.physics.box2d.World;
import com.mygdx.game.GameSettings;

public class BulletObject extends GameObject {
    public boolean pendingRemoval = false;

    public BulletObject(int x, int y, int width, int height, String texturePath, World world) {
        super(texturePath, x, y, width, height, GameSettings.BULLET_BIT, world);

        body.setLinearVelocity(0, GameSettings.BULLET_SPEED);

        body.setGravityScale(0f);
        body.setFixedRotation(true);
        body.setBullet(true);
        com.badlogic.gdx.physics.box2d.Filter filter = new com.badlogic.gdx.physics.box2d.Filter();
        filter.categoryBits = GameSettings.BULLET_BIT;
        filter.maskBits =  GameSettings.TRASH_BIT;
        body.getFixtureList().get(0).setFilterData(filter);
    }

    public boolean isOutOfBounds() {
        return !alive || getY() > GameSettings.SCREEN_HEIGHT + 50;
    }
}