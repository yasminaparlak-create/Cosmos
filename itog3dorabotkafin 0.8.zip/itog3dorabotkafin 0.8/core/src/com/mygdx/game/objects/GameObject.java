package com.mygdx.game.objects;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.physics.box2d.*;
import com.mygdx.game.GameSettings;

public class GameObject extends Sprite {

    public Body body;
    public boolean alive = true;
    public final int width, height;

    public GameObject(String texturePath, int x, int y, int width, int height, int categoryBit, World world) {
        super(new Texture(Gdx.files.internal(texturePath)));

        this.width = width;
        this.height = height;

        setSize(width, height);
        setOrigin(width / 2f, height / 2f);

        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;

        bodyDef.position.set(x / GameSettings.PPM, y / GameSettings.PPM);
        body = world.createBody(bodyDef);

        // форма коллизии
        PolygonShape shape = new PolygonShape();
        //  в метрах
        shape.setAsBox(width / 2f / GameSettings.PPM, height / 2f / GameSettings.PPM);

        // физика
        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 1.0f;
        fixtureDef.friction = 0.4f;
        fixtureDef.restitution = 0.1f;

        fixtureDef.filter.categoryBits = (short) categoryBit;
        fixtureDef.filter.maskBits = (short) -1;

        Fixture fixture = body.createFixture(fixtureDef);
        fixture.setUserData(this);
        body.setUserData(this);

        shape.dispose();
    }

    public void draw(SpriteBatch batch) {
        if (alive && body != null) {

            float posX = body.getPosition().x * GameSettings.PPM;
            float posY = body.getPosition().y * GameSettings.PPM;

            setPosition(posX - width / 2f, posY - height / 2f);

            setRotation(body.getAngle() * MathUtils.radiansToDegrees);

            super.draw(batch);
        }
    }

    @Override
    public float getX() {
        return body != null ? body.getPosition().x * GameSettings.PPM : super.getX();
    }

    @Override
    public float getY() {
        return body != null ? body.getPosition().y * GameSettings.PPM : super.getY();
    }

    public void hit() {
        alive = false;
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    public boolean isAlive() {
        return alive;
    }

    public void destroy() {
        if (body != null) {

            if (body.getWorld() != null) {
                body.getWorld().destroyBody(body);
            }
            body = null;
        }
        alive = false;
    }
    public void setTexture(String texturePath) {
        setRegion(new TextureRegion(new Texture(texturePath)));
    }
}