package com.mygdx.game;

public class GameSettings {

    public static final int SHIP_WIDTH = 135;
    public static final int SHIP_HEIGHT = 128;
    public static final int BULLET_WIDTH = 25;
    public static final int BULLET_HEIGHT = 55;
    public static final int TRASH_WIDTH = 128;
    public static final int TRASH_HEIGHT = 128;
    public static final int LOOT_WIDTH = 85;
    public static final int LOOT_HEIGHT = 85;
    // Скорости
    public static final float TRASH_SPEED = 500f;

    public static final float BULLET_SPEED = 8f;  // В метрах в секунду

    public static final float LOOT_FALL_SPEED = 2f;

    // Остальное
    public static final float PPM = 100f; // 100 пикселей = 1 метр
    public static final float SHOOTING_COOL_DOWN = 400f; // мс
    public static final float LOOT_DROP_CHANCE = 0.10f;
    public static final float STARTING_TRASH_APPEARANCE_COOL_DOWN = 0.45f;
    public static final int SCREEN_WIDTH = 720;
    public static final int SCREEN_HEIGHT = 1280;
    public static final float STEP_TIME = 1f / 60f;
    public static final int VELOCITY_ITERATIONS = 5;
    public static final int POSITION_ITERATIONS = 10;

    public static final short TRASH_BIT = 2;
    public static final short SHIP_BIT = 4;
    public static final short LOOT_BIT = 16;
    public static final short BULLET_BIT = 8;
}
