package com.mygdx.game.pools;

import com.badlogic.gdx.utils.Pool;
import com.badlogic.gdx.physics.box2d.World;
import com.mygdx.game.GameSettings;
import com.mygdx.game.GameResources;
import com.mygdx.game.objects.TrashObject;

public class TrashPool extends Pool<TrashObject> {
    private final World world;

    public TrashPool(World world, int initialCapacity, int maxSize) {
        super(initialCapacity, maxSize);
        this.world = world;
    }

    @Override
    protected TrashObject newObject() {

        return new TrashObject(
                GameSettings.TRASH_WIDTH,
                GameSettings.TRASH_HEIGHT,
                GameResources.getRandomTexturePath(),
                world,
                GameSettings.TRASH_SPEED,
                0f
        );
    }

    @Override
    protected void reset(TrashObject trash) {

        trash.alive = false;
        trash.setDestroyedByBullet(false);

        trash.body.setActive(false);
        trash.body.setTransform(0, -100, 0);

        trash.body.setLinearVelocity(0, 0);
        trash.body.setAngularVelocity(0);
        trash.body.setAngularDamping(0);
        trash.body.setGravityScale(0f);
    }

    public TrashObject obtain(float speed, float xSpeed) {

        TrashObject trash = super.obtain();

        trash.alive = true;
        trash.setDestroyedByBullet(false);

        trash.body.setActive(true);

        float spawnX = (float) (Math.random() * (GameSettings.SCREEN_WIDTH - GameSettings.TRASH_WIDTH));
        trash.body.setTransform(
                spawnX / GameSettings.PPM,
                (GameSettings.SCREEN_HEIGHT + 100) / GameSettings.PPM,
                0
        );

        trash.body.setLinearVelocity(
                xSpeed / GameSettings.PPM,
                -speed / GameSettings.PPM
        );

        float spinSpeed = (float) ((Math.random() - 0.5) * 6f);
        trash.body.setAngularVelocity(spinSpeed);
        trash.body.setAngularDamping(1.0f);

        return trash;
    }
}