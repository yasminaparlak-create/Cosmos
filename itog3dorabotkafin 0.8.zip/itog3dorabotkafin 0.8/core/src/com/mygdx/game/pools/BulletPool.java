package com.mygdx.game.pools;

import com.badlogic.gdx.utils.Pool;
import com.badlogic.gdx.physics.box2d.World;
import com.mygdx.game.GameResources;
import com.mygdx.game.GameSettings;
import com.mygdx.game.objects.BulletObject;

public class BulletPool extends Pool<BulletObject> {
    private final World world;
    private final int width, height;

    public BulletPool(World world, int initialCapacity, int maxSize) {
        super(initialCapacity, maxSize);
        this.world = world;
        this.width = GameSettings.BULLET_WIDTH;
        this.height = GameSettings.BULLET_HEIGHT;
    }

    @Override
    protected BulletObject newObject() {
        return new BulletObject(0, 0, width, height, GameResources.BULLET_IMG_PATH, world);
    }

    @Override
    protected void reset(BulletObject bullet) {

        bullet.alive = false;
        bullet.body.setActive(false);
        bullet.body.setTransform(0, -100, 0);
        bullet.body.setLinearVelocity(0, 0);
    }


    public BulletObject obtain(int x, int y) {
        BulletObject bullet = super.obtain();
        bullet.alive = true;
        bullet.body.setActive(true);
        bullet.body.setTransform(x / GameSettings.PPM, y / GameSettings.PPM, 0);
        bullet.body.setLinearVelocity(0, GameSettings.BULLET_SPEED);
        return bullet;
    }
}