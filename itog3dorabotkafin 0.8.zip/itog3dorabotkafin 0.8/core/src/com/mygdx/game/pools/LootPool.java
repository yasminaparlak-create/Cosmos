package com.mygdx.game.pools;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Pool;
import com.badlogic.gdx.physics.box2d.World;
import com.mygdx.game.GameResources;
import com.mygdx.game.GameSettings;
import com.mygdx.game.objects.LootObject;
import com.mygdx.game.objects.LootType;

public class LootPool extends Pool<LootObject> {
    private final World world;

    public LootPool(World world, int initialCapacity, int maxSize) {
        super(initialCapacity, maxSize);
        this.world = world;
    }

    @Override
    protected LootObject newObject() {

        return new LootObject(
                0,
                0,
                LootType.RAPID_FIRE,
                GameResources.LOOT_RAPID_FIRE_PATH,
                world
        );
    }

    @Override
    protected void reset(LootObject loot) {

        loot.alive = false;
        loot.collected = false;

        loot.body.setActive(false);
        loot.body.setTransform(0, -100, 0);

        loot.body.setLinearVelocity(0, 0);
        loot.body.setAngularVelocity(0);
        loot.body.setGravityScale(0.3f);
    }

    public LootObject obtain(int x, int y, LootType type, String texturePath) {
        LootObject loot = super.obtain();

        loot.alive = true;
        loot.collected = false;
        loot.type = type;

        if (texturePath != null && !texturePath.isEmpty()) {

            TextureRegion region = new TextureRegion(
                    new com.badlogic.gdx.graphics.Texture(texturePath)
            );
            loot.setRegion(region);

        }

        loot.body.setActive(true);
        loot.body.setTransform(x / GameSettings.PPM, y / GameSettings.PPM, 0);

        loot.body.setLinearVelocity(0, -GameSettings.LOOT_FALL_SPEED);
        loot.body.setAngularVelocity(0);

        return loot;
    }
}