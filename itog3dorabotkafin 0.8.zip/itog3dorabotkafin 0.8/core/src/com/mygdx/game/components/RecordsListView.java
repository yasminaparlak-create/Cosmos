package com.mygdx.game.components;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.mygdx.game.GameSettings;

import java.util.ArrayList;

public class RecordsListView extends TextView {

    public RecordsListView(BitmapFont font, float y) {
        super(font, 0, y, "");
    }

    public void setRecords(ArrayList<Integer> recordsList) {
        //  Защита от null
        if (recordsList == null || recordsList.isEmpty()) {
            this.text = "No records yet";
            centerText();
            return;
        }

        StringBuilder sb = new StringBuilder();

        int countOfRows = Math.min(recordsList.size(), 5);

        for (int i = 0; i < countOfRows; i++) {
            sb.append(i + 1).append(". - ").append(recordsList.get(i)).append("\n");
        }

        this.text = sb.toString();
        centerText();
    }


    private void centerText() {
        GlyphLayout glyphLayout = new GlyphLayout(font, text);
        this.x = (GameSettings.SCREEN_WIDTH - glyphLayout.width) / 2f;
    }
}