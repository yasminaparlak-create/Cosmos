package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.GameResources;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.components.ButtonView;
import com.mygdx.game.components.ImageView;
import com.mygdx.game.components.MovingBackgroundView;
import com.mygdx.game.components.TextView;
import com.mygdx.game.managers.MemoryManager;

public class SkinScreen extends ScreenAdapter {
    private final MyGdxGame myGdxGame;
    private final MovingBackgroundView backgroundView;
    private final TextView titleTextView;
    private final ButtonView returnButton;
    private final ImageView skinShipFonImageView;

    private final ButtonView skin1ShipButtonView;
    private final ButtonView skin2ShipButtonView;
    private final ButtonView skin3ShipButtonView;
    private final ButtonView skin4ShipButtonView;

    private Sprite[] skinFrames;
    private Texture skinFrameTexture;
    private int selectedSkinIndex = -1;

    public record SkinData(ButtonView view, String name, String path) {}

    public SkinScreen(MyGdxGame myGdxGame) {
        this.myGdxGame = myGdxGame;

        backgroundView = new MovingBackgroundView(GameResources.BACKGROUND_IMG_PATH);

        titleTextView = new TextView(myGdxGame.largeWhiteFont, 0, 1060, "Skins");
        titleTextView.centerX();

        returnButton = new ButtonView(
                140, 171, 440, 70,
                myGdxGame.commonBlackFont,
                GameResources.BUTTON_LONG_BG_IMG_PATH,
                "Home"
        );

        skinShipFonImageView = new ImageView(85, 336, GameResources.BLACKOUT_SC_IMG_PATH);

        skin1ShipButtonView = new ButtonView(125, 686, 200, 70, myGdxGame.commonWhiteFont, GameResources.BLACKOUT_MIDDLE_IMG_PATH, "");
        skin2ShipButtonView = new ButtonView(395, 686, 200, 70, myGdxGame.commonWhiteFont, GameResources.BLACKOUT_MIDDLE_IMG_PATH, "");
        skin3ShipButtonView = new ButtonView(125, 390, 200, 70, myGdxGame.commonWhiteFont, GameResources.BLACKOUT_MIDDLE_IMG_PATH, "");
        skin4ShipButtonView = new ButtonView(395, 390, 200, 70, myGdxGame.commonWhiteFont, GameResources.BLACKOUT_MIDDLE_IMG_PATH, "");

        initSkinFrames();
        loadAndApplySavedSkin(); // (azurean по умолчанию)
    }

    private void initSkinFrames() {
        skinFrameTexture = new Texture(Gdx.files.internal("textures/frame.png"));
        skinFrames = new Sprite[4];

        skinFrames[0] = createFrameFor(skin1ShipButtonView, skinFrameTexture);
        skinFrames[1] = createFrameFor(skin2ShipButtonView, skinFrameTexture);
        skinFrames[2] = createFrameFor(skin3ShipButtonView, skinFrameTexture);
        skinFrames[3] = createFrameFor(skin4ShipButtonView, skinFrameTexture);

        for (Sprite frame : skinFrames) {
            frame.setColor(1, 1, 1, 0);
        }
    }

    private Sprite createFrameFor(ButtonView view, Texture tex) {
        Sprite frame = new Sprite(tex);
        frame.setSize(view.width + 48, view.height + 213);
        frame.setPosition(view.x - 24, view.y - 25);
        return frame;
    }

    private void loadAndApplySavedSkin() {

        selectedSkinIndex = MemoryManager.loadSelectedSkinIndex();
        SkinData[] skins = getSkinData();

        for (int i = 0; i < skins.length; i++) {
            skins[i].view.setText(i == selectedSkinIndex ? "current" : skins[i].name);
        }

        if (selectedSkinIndex >= 0 && selectedSkinIndex < skinFrames.length) {
            skinFrames[selectedSkinIndex].setColor(1, 1, 1, 1);
            GameResources.SHIP_IMG_PATH = skins[selectedSkinIndex].path;
        }
    }

    private SkinData[] getSkinData() {
        return new SkinData[]{
                new SkinData(skin1ShipButtonView, "citrine", "textures/ship1.png"),
                new SkinData(skin2ShipButtonView, "verdant", "textures/ship2.png"),
                new SkinData(skin3ShipButtonView, "azurean", "textures/ship3.png"),
                new SkinData(skin4ShipButtonView, "nankeen", "textures/ship4.png")
        };
    }

    private void skinSelection() {
        SkinData[] skins = getSkinData();

        for (int i = 0; i < skins.length; i++) {
            if (skins[i].view.isHit(myGdxGame.touch.x, myGdxGame.touch.y)) {

                if (selectedSkinIndex != -1 && selectedSkinIndex < skinFrames.length) {
                    skinFrames[selectedSkinIndex].setColor(1, 1, 1, 0);
                }

                for (int j = 0; j < skins.length; j++) {
                    skins[j].view.setText(i == j ? "current" : skins[j].name);
                }

                if (MyGdxGame.audioManager.isSoundOn) {
                    MyGdxGame.audioManager.BtnClick.play();
                }

                skinFrames[i].setColor(1, 1, 1, 1);

                GameResources.SHIP_IMG_PATH = skins[i].path;
                MemoryManager.saveShipImagePath(skins[i].path);
                MemoryManager.saveSelectedSkinIndex(i);

                selectedSkinIndex = i;
                break;
            }
        }
    }

    @Override
    public void render(float delta) {
        handleInput();

        myGdxGame.camera.update();
        myGdxGame.batch.setProjectionMatrix(myGdxGame.camera.combined);
        ScreenUtils.clear(Color.CLEAR);

        myGdxGame.batch.begin();

        backgroundView.draw(myGdxGame.batch);
        titleTextView.draw(myGdxGame.batch);
        skinShipFonImageView.draw(myGdxGame.batch);
        returnButton.draw(myGdxGame.batch);

        skin1ShipButtonView.draw(myGdxGame.batch);
        skin2ShipButtonView.draw(myGdxGame.batch);
        skin3ShipButtonView.draw(myGdxGame.batch);
        skin4ShipButtonView.draw(myGdxGame.batch);

        if (skinFrames != null) {
            for (Sprite frame : skinFrames) {
                if (frame != null) frame.draw(myGdxGame.batch);
            }
        }

        myGdxGame.batch.end();
    }

    private void handleInput() {
        if (Gdx.input.justTouched()) {
            myGdxGame.touch = myGdxGame.camera.unproject(new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0));

            if (returnButton.isHit(myGdxGame.touch.x, myGdxGame.touch.y)) {

                if (MyGdxGame.audioManager.isSoundOn) {
                    MyGdxGame.audioManager.BtnClick.play();
                }
                myGdxGame.setScreen(myGdxGame.menuScreen);
                return;
            }

            skinSelection();
        }
    }

    @Override
    public void dispose() {
        if (skinFrameTexture != null) {
            skinFrameTexture.dispose();
            skinFrameTexture = null;
        }
        skinFrames = null;

        if (backgroundView != null) backgroundView.dispose();
        if (skinShipFonImageView != null) skinShipFonImageView.dispose();
        if (returnButton != null) returnButton.dispose();
        if (skin1ShipButtonView != null) skin1ShipButtonView.dispose();
        if (skin2ShipButtonView != null) skin2ShipButtonView.dispose();
        if (skin3ShipButtonView != null) skin3ShipButtonView.dispose();
        if (skin4ShipButtonView != null) skin4ShipButtonView.dispose();
    }
}