package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.GameResources;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.components.ButtonView;
import com.mygdx.game.components.ImageView;
import com.mygdx.game.components.MovingBackgroundView;
import com.mygdx.game.components.TextView;
import com.mygdx.game.managers.MemoryManager;

public class MenuScreen extends ScreenAdapter{
        MyGdxGame myGdxGame;

        MovingBackgroundView backgroundView;
        TextView titleView;



        ButtonView startButtonView;
        ButtonView skinButtonView;
        ButtonView settingsButtonView;
        private ImageView shipPreview;



        public MenuScreen(MyGdxGame myGdxGame) {
            this.myGdxGame = myGdxGame;
            backgroundView = new MovingBackgroundView(GameResources.BACKGROUND_IMG_PATH);
            titleView = new TextView(myGdxGame.largeWhiteFont, 0, 1060, "Home");
            titleView.centerX();

            settingsButtonView = new ButtonView(140, 361, 440, 70, myGdxGame.commonBlackFont, GameResources.BUTTON_LONG_BG_IMG_PATH, "Settings");
            skinButtonView = new ButtonView(140, 266,440, 70, myGdxGame.commonBlackFont, GameResources.BUTTON_LONG_BG_IMG_PATH,"Skins");
            startButtonView = new ButtonView(140, 171, 440, 70, myGdxGame.commonBlackFont, GameResources.BUTTON_LONG_BG_IMG_PATH, "Start");

            shipPreview = new ImageView(232, 512, MemoryManager.loadShipImagePath());
        }

         @Override
        public void show() {
           updateShipPreview();
         }
    private void updateShipPreview() {
        String currentPath = MemoryManager.loadShipImagePath();

        if (shipPreview != null) {
            shipPreview.dispose();
        }

        shipPreview = new ImageView(104, 568, currentPath);
    }

        @Override
        public void render(float delta) {

            handleInput();

            myGdxGame.camera.update();
            myGdxGame.batch.setProjectionMatrix(myGdxGame.camera.combined);
            ScreenUtils.clear(Color.CLEAR);

            myGdxGame.batch.begin();


            backgroundView.draw(myGdxGame.batch);
            titleView.draw(myGdxGame.batch);
            shipPreview.draw(myGdxGame.batch);

            settingsButtonView.draw(myGdxGame.batch);
            skinButtonView.draw(myGdxGame.batch);
            startButtonView.draw(myGdxGame.batch);

            myGdxGame.batch.end();
        }

        private void handleInput() {
            if (Gdx.input.justTouched()) {
                myGdxGame.touch = myGdxGame.camera.unproject(new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0));

                if (startButtonView.isHit(myGdxGame.touch.x, myGdxGame.touch.y)) {
                    if (MyGdxGame.audioManager.isSoundOn) MyGdxGame.audioManager.BtnClick.play();
                    myGdxGame.setScreen(myGdxGame.gameScreen);
                }

                if (settingsButtonView.isHit(myGdxGame.touch.x, myGdxGame.touch.y)) {
                    if (MyGdxGame.audioManager.isSoundOn) MyGdxGame.audioManager.BtnClick.play();
                    myGdxGame.setScreen(myGdxGame.settingsScreen);
                }
                if (skinButtonView.isHit(myGdxGame.touch.x, myGdxGame.touch.y)) {
                    if (MyGdxGame.audioManager.isSoundOn) MyGdxGame.audioManager.BtnClick.play();
                    myGdxGame.setScreen(myGdxGame.skinScreen);
                }
            }
        }

        @Override
        public void dispose() {
            if (shipPreview != null) shipPreview.dispose();
            if (backgroundView != null) backgroundView.dispose();
            if (startButtonView != null) startButtonView.dispose();
            if (skinButtonView != null) skinButtonView.dispose();
            if (settingsButtonView != null) settingsButtonView.dispose();
        }
    }
