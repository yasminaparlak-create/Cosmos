package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;

import com.mygdx.game.MyGdxGame;
import com.mygdx.game.GameSession;
import com.mygdx.game.GameState;
import com.mygdx.game.GameSettings;
import com.mygdx.game.GameResources;
import com.mygdx.game.objects.LootType;

import com.mygdx.game.objects.ShipObject;
import com.mygdx.game.objects.TrashObject;
import com.mygdx.game.objects.BulletObject;
import com.mygdx.game.objects.LootObject;
import com.mygdx.game.components.LiveView;
import com.mygdx.game.components.TextView;
import com.mygdx.game.components.ButtonView;
import com.mygdx.game.components.ImageView;
import com.mygdx.game.components.MovingBackgroundView;
import com.mygdx.game.components.RecordsListView;

import com.mygdx.game.managers.ContactManager;
import com.mygdx.game.managers.MemoryManager;
import com.mygdx.game.managers.ExplosionManager;
import com.mygdx.game.pools.BulletPool;
import com.mygdx.game.pools.LootPool;      // ← ДОБАВЛЕНО
import com.mygdx.game.pools.TrashPool;     // ← ДОБАВЛЕНО

public class GameScreen extends ScreenAdapter {

    ShipObject shipObject;

    private final MyGdxGame myGdxGame;
    private final GameSession gameSession;
    private final ContactManager contactManager;

    // Пулы и списки активных объектов
    private final BulletPool bulletPool;
    private final Array<BulletObject> activeBullets;

    private final LootPool lootPool;        // ← ДОБАВЛЕНО
    private final Array<LootObject> activeLoot;

    private final TrashPool trashPool;      // ← ДОБАВЛЕНО
    private final Array<TrashObject> activeTrash;

    private final ExplosionManager explosionManager;

    // UI
    MovingBackgroundView backgroundView;
    ImageView topBlackoutView;
    LiveView liveView;
    TextView scoreTextView;
    ButtonView pauseButton;

    TextView rapidFireView;
    TextView shieldView;
    TextView scoreBoostView;

    ImageView fullBlackoutView;
    TextView pauseTextView;
    ButtonView homeButton, continueButton;
    ImageView blackoutImageView;
    TextView recordsTextView;
    RecordsListView recordsListView;
    ButtonView homeButton2;

    public GameScreen(MyGdxGame myGdxGame) {
        this.myGdxGame = myGdxGame;
        gameSession = new GameSession();
        contactManager = new ContactManager();


        bulletPool = new BulletPool(myGdxGame.world, 10, 60);
        activeBullets = new Array<>();

        lootPool = new LootPool(myGdxGame.world, 10, 30);
        activeLoot = new Array<>();

        trashPool = new TrashPool(myGdxGame.world, 15, 50);
        activeTrash = new Array<>();

        explosionManager = new ExplosionManager(
                new TextureRegion(new Texture(Gdx.files.internal(GameResources.BULLET_IMG_PATH)))
        );

        shipObject = new ShipObject(
                GameSettings.SCREEN_WIDTH / 2, 150,
                GameSettings.SHIP_WIDTH, GameSettings.SHIP_HEIGHT,
                GameResources.SHIP_IMG_PATH,
                myGdxGame.world
        );

        // UI
        backgroundView = new MovingBackgroundView(GameResources.BACKGROUND_IMG_PATH);
        topBlackoutView = new ImageView(0, 1150, GameResources.BLACKOUT_TOP_IMG_PATH);
        liveView = new LiveView(30, 1160);
        scoreTextView = new TextView(myGdxGame.largeWhiteFont, 30, 1220);
        pauseButton = new ButtonView(605, 1170, 85, 95, GameResources.PAUSE_IMG_PATH);

        rapidFireView = new TextView(myGdxGame.smallFont, 30, 1100, "");
        shieldView    = new TextView(myGdxGame.smallFont, 30, 1060, "");
        scoreBoostView= new TextView(myGdxGame.smallFont, 30, 1020, "");

        fullBlackoutView = new ImageView(0, 0, GameResources.BLACKOUT_FULL_IMG_PATH);
        pauseTextView = new TextView(myGdxGame.largeWhiteFont, 0, 1060, "Pause");
        pauseTextView.centerX();

        continueButton = new ButtonView(140, 266, 440, 70, myGdxGame.commonBlackFont, GameResources.BUTTON_LONG_BG_IMG_PATH, "Continue");
        homeButton = new ButtonView(140, 171, 440, 70, myGdxGame.commonBlackFont, GameResources.BUTTON_LONG_BG_IMG_PATH, "Home");

        recordsTextView = new TextView(myGdxGame.largeWhiteFont, 0, 1060, "Last records");
        recordsTextView.centerX();
        blackoutImageView = new ImageView(85, 465, GameResources.BLACKOUT_MIDDLE_IMG_PATH);
        recordsListView = new RecordsListView(myGdxGame.commonWhiteFont, 817);
        homeButton2 = new ButtonView(140, 171, 440, 70, myGdxGame.commonBlackFont, GameResources.BUTTON_LONG_BG_IMG_PATH, "Home");
    }

    @Override
    public void show() {
        restartGame();
        myGdxGame.world.setContactListener(contactManager);
    }

    @Override
    public void render(float delta) {
        handleInput();

        if (gameSession.state == GameState.PLAYING) {
            gameSession.update(delta);

            // СПАВН МУСОРА
            if (gameSession.shouldSpawnTrash()) {
                float currentSpeed = GameSettings.TRASH_SPEED * gameSession.getTrashSpeedMultiplier();
                float chaosFactor = gameSession.getDifficultyMultiplier() - 1.0f;
                float xSpeed = (float) (Math.random() * 400 * chaosFactor - 200 * chaosFactor);

                TrashObject trash = trashPool.obtain(currentSpeed, xSpeed);
                activeTrash.add(trash);
            }

            //  СТРЕЛЬБА
            if (shipObject.needToShoot()) {
                float cx = shipObject.getX();
                float cy = shipObject.getY() + shipObject.height / 2f;

                if (shipObject.rapidFireTimer > 0) {
                    BulletObject bulletL = bulletPool.obtain((int)(cx - 12), (int)cy);
                    BulletObject bulletR = bulletPool.obtain((int)(cx + 12), (int)cy);
                    activeBullets.add(bulletL);
                    activeBullets.add(bulletR);
                } else {
                    BulletObject bullet = bulletPool.obtain((int)cx, (int)cy);
                    activeBullets.add(bullet);
                }

                if (MyGdxGame.audioManager.isSoundOn) {
                    MyGdxGame.audioManager.shootSound.play();
                }
            }


            myGdxGame.stepWorld();

            updateTrash();
            updateBullets();
            updateLoot();

            shipObject.update(delta);
            shipObject.constrainToScreen();
            backgroundView.move();

            gameSession.updateScore();

            if (explosionManager != null) {
                explosionManager.update(delta);
            }

            // UI
            scoreTextView.setText("Score: " + gameSession.getScore());
            liveView.setLeftLives(shipObject.getLiveLeft());
            updateBuffText();

            if (shipObject != null && !shipObject.isAlive()) {
                gameSession.endGame();
                recordsListView.setRecords(MemoryManager.loadRecordsTable());
            }
        }

        draw();
    }

    private void handleInput() {
        if (Gdx.input.isTouched()) {
            myGdxGame.touch = myGdxGame.camera.unproject(
                    new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0)
            );

            switch (gameSession.state) {
                case PLAYING:
                    if (pauseButton.isHit(myGdxGame.touch.x, myGdxGame.touch.y)) {
                        if (MyGdxGame.audioManager.isSoundOn) {
                            MyGdxGame.audioManager.BtnClick.play();
                        }
                        gameSession.pauseGame();
                    } else {
                        shipObject.move(myGdxGame.touch);
                    }
                    break;
                case PAUSED:
                    if (continueButton.isHit(myGdxGame.touch.x, myGdxGame.touch.y)) {
                        if (MyGdxGame.audioManager.isSoundOn) {
                            MyGdxGame.audioManager.BtnClick.play();
                        }
                        gameSession.resumeGame();
                    }
                    if (homeButton.isHit(myGdxGame.touch.x, myGdxGame.touch.y)) {
                        if (MyGdxGame.audioManager.isSoundOn) {
                            MyGdxGame.audioManager.BtnClick.play();
                        }
                        myGdxGame.setScreen(myGdxGame.menuScreen);
                    }
                    break;
                case ENDED:
                    if (homeButton2.isHit(myGdxGame.touch.x, myGdxGame.touch.y)) {
                        if (MyGdxGame.audioManager.isSoundOn) {
                            MyGdxGame.audioManager.BtnClick.play();
                        }
                        myGdxGame.setScreen(myGdxGame.menuScreen);
                    }
                    break;
            }
        }
    }

    private void draw() {
        myGdxGame.camera.update();
        myGdxGame.batch.setProjectionMatrix(myGdxGame.camera.combined);
        ScreenUtils.clear(Color.CLEAR);

        myGdxGame.batch.begin();

        backgroundView.draw(myGdxGame.batch);

        // отрисовка через пулы
        for (TrashObject t : activeTrash) if (t.alive) t.draw(myGdxGame.batch);
        if (shipObject != null && shipObject.isAlive()) shipObject.draw(myGdxGame.batch);
        for (BulletObject b : activeBullets) if (b.alive) b.draw(myGdxGame.batch);
        for (LootObject l : activeLoot) if (l.alive && !l.collected) l.draw(myGdxGame.batch);

        if (explosionManager != null) {
            explosionManager.draw(myGdxGame.batch);
        }

        topBlackoutView.draw(myGdxGame.batch);
        scoreTextView.draw(myGdxGame.batch);
        liveView.draw(myGdxGame.batch);
        pauseButton.draw(myGdxGame.batch);
        rapidFireView.draw(myGdxGame.batch);
        shieldView.draw(myGdxGame.batch);
        scoreBoostView.draw(myGdxGame.batch);

        if (gameSession.state == GameState.PAUSED) {
            fullBlackoutView.draw(myGdxGame.batch);
            pauseTextView.draw(myGdxGame.batch);
            homeButton.draw(myGdxGame.batch);
            continueButton.draw(myGdxGame.batch);
        } else if (gameSession.state == GameState.ENDED) {
            fullBlackoutView.draw(myGdxGame.batch);
            recordsTextView.draw(myGdxGame.batch);
            blackoutImageView.draw(myGdxGame.batch);
            recordsListView.draw(myGdxGame.batch);
            homeButton2.draw(myGdxGame.batch);
        }

        myGdxGame.batch.end();
    }

    private void updateTrash() {
        for (int i = activeTrash.size - 1; i >= 0; i--) {
            TrashObject trash = activeTrash.get(i);

            if (!trash.alive || trash.getY() < -100) {
                if (trash.isDestroyedByBullet()) {
                    if (explosionManager != null) {
                        explosionManager.spawnExplosion((int) trash.getX(), (int) trash.getY(), 20);
                    }
                    int points = 100 * shipObject.scoreMultiplier;
                    gameSession.addScore(points);
                    gameSession.destructionRegistration();

                    if (Math.random() < GameSettings.LOOT_DROP_CHANCE) {
                        spawnLoot((int) trash.getX(), (int) trash.getY());
                    }
                }


                trashPool.free(trash);
                activeTrash.removeIndex(i);
            }
        }
    }

    private void updateBullets() {
        for (int i = activeBullets.size - 1; i >= 0; i--) {
            BulletObject b = activeBullets.get(i);

            if (b.isOutOfBounds() || b.pendingRemoval) {
                activeBullets.removeIndex(i);

                if (!b.pendingRemoval) {
                    bulletPool.free(b);
                }
            }
        }
    }

    private void updateLoot() {
        for (int i = activeLoot.size - 1; i >= 0; i--) {
            LootObject l = activeLoot.get(i);

            if (l.shouldBeRemoved()) {

                if (l.collected) {
                    applyLootEffect(l.type);
                }

                lootPool.free(l);
                activeLoot.removeIndex(i);
            }
        }
    }

    private void spawnLoot(int x, int y) {
        LootType[] types = LootType.values();
        int index = (int) (Math.random() * types.length);
        LootType type = types[index];

        String[] paths = {
                GameResources.LOOT_RAPID_FIRE_PATH,
                GameResources.LOOT_SHIELD_PATH,
                GameResources.LOOT_EXTRA_LIFE_PATH,
                GameResources.LOOT_SCORE_BOOST_PATH
        };

        LootObject loot = lootPool.obtain(x, y, type, paths[index]);
        activeLoot.add(loot);
    }
    private void applyLootEffect(LootType type) {

        shipObject.applyLoot(type);

        if (MyGdxGame.audioManager.isSoundOn) {
            MyGdxGame.audioManager.shootSound.play(0.3f);
        }
    }

    private void updateBuffText() {
        rapidFireView.setText(shipObject.rapidFireTimer > 0
                ? "RAPID: " + (int) shipObject.rapidFireTimer + "s" : "");
        shieldView.setText(shipObject.hasShield ? "SHIELD ON" : "");
        scoreBoostView.setText((shipObject.scoreMultiplier > 1 && shipObject.scoreBoostTimer > 0)
                ? "x2 SCORE: " + (int) shipObject.scoreBoostTimer + "s" : "");
    }

    private void restartGame() {

        for (TrashObject t : activeTrash) trashPool.free(t);
        activeTrash.clear();

        for (BulletObject b : activeBullets) bulletPool.free(b);
        activeBullets.clear();

        for (LootObject l : activeLoot) lootPool.free(l);
        activeLoot.clear();

        if (shipObject != null) {
            shipObject.destroy();
            shipObject.dispose();
        }
        shipObject = new ShipObject(
                GameSettings.SCREEN_WIDTH / 2, 150,
                GameSettings.SHIP_WIDTH, GameSettings.SHIP_HEIGHT,
                GameResources.SHIP_IMG_PATH,
                myGdxGame.world
        );

        gameSession.startGame();

        if (explosionManager != null) {
            explosionManager.clear();
        }
    }

    @Override
    public void dispose() {

        for (TrashObject t : activeTrash) trashPool.free(t);
        for (BulletObject b : activeBullets) bulletPool.free(b);
        for (LootObject l : activeLoot) lootPool.free(l);

        if (shipObject != null) {
            shipObject.destroy();
            shipObject.dispose();
        }
        if (explosionManager != null) {
            explosionManager.dispose();
        }
    }
}