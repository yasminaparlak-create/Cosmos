package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.GameResources;
import com.mygdx.game.managers.MemoryManager;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.components.ButtonView;
import com.mygdx.game.components.ImageView;
import com.mygdx.game.components.MovingBackgroundView;
import com.mygdx.game.components.TextView;

public class SettingsScreen extends ScreenAdapter {
    MyGdxGame myGdxGame;

    MovingBackgroundView backgroundView;
    TextView titleTextView;
    ImageView blackoutImageView;
    ButtonView returnButton;
    TextView musicSettingView;
    TextView soundSettingView;
    TextView clearSettingView;

    public SettingsScreen(MyGdxGame myGdxGame) {
        this.myGdxGame = myGdxGame;

        backgroundView = new MovingBackgroundView(GameResources.BACKGROUND_IMG_PATH);

        titleTextView = new TextView(myGdxGame.largeWhiteFont, 0, 1060, "Settings");
        titleTextView.centerX();

        blackoutImageView = new ImageView(85, 491, GameResources.BLACKOUT_MIDDLE_IMG_PATH);
        clearSettingView = new TextView(myGdxGame.commonWhiteFont, 125, 679, "clear records");


        musicSettingView = new TextView(
                myGdxGame.commonWhiteFont, 125, 857, "music: ON"
        );
        soundSettingView = new TextView(
                myGdxGame.commonWhiteFont, 125, 798, "sound: ON"
        );

        returnButton = new ButtonView(
                140, 171, 440, 70,
                myGdxGame.commonBlackFont,
                GameResources.BUTTON_LONG_BG_IMG_PATH,
                "Home"
        );
    }

    private void updateSettingsTexts() {
        boolean isMusicOn = MemoryManager.loadIsMusicOn();
        boolean isSoundOn = MemoryManager.loadIsSoundOn();

        MyGdxGame.audioManager.isMusicOn = isMusicOn;
        MyGdxGame.audioManager.isSoundOn = isSoundOn;

        musicSettingView.setText("music: " + translateStateToText(isMusicOn));
        soundSettingView.setText("sound: " + translateStateToText(isSoundOn));
    }

    @Override
    public void show() {
        super.show();
        updateSettingsTexts();
        clearSettingView.setText("clear records");
    }

    @Override
    public void render(float delta) {
        handleInput();

        myGdxGame.camera.update();
        myGdxGame.batch.setProjectionMatrix(myGdxGame.camera.combined);
        ScreenUtils.clear(Color.CLEAR);

        myGdxGame.batch.begin();

        backgroundView.draw(myGdxGame.batch);
        titleTextView.draw(myGdxGame.batch);
        blackoutImageView.draw(myGdxGame.batch);
        returnButton.draw(myGdxGame.batch);
        musicSettingView.draw(myGdxGame.batch);
        soundSettingView.draw(myGdxGame.batch);
        clearSettingView.draw(myGdxGame.batch);

        myGdxGame.batch.end();
    }

    void handleInput() {
        if (Gdx.input.justTouched()) {
            myGdxGame.touch = myGdxGame.camera.unproject(new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0));

            if (returnButton.isHit(myGdxGame.touch.x, myGdxGame.touch.y)) {
                if (MyGdxGame.audioManager.isSoundOn) MyGdxGame.audioManager.BtnClick.play();
                myGdxGame.setScreen(myGdxGame.menuScreen);
            }
            if (clearSettingView.isHit(myGdxGame.touch.x, myGdxGame.touch.y)) {
                if (MyGdxGame.audioManager.isSoundOn) MyGdxGame.audioManager.BtnClick.play();
                MemoryManager.clearRecords();
                clearSettingView.setText("clear records\n(cleared)");
            }
            if (musicSettingView.isHit(myGdxGame.touch.x, myGdxGame.touch.y)) {
                MyGdxGame.audioManager.toggleMusic();
                if (MyGdxGame.audioManager.isSoundOn) MyGdxGame.audioManager.BtnClick.play();
                musicSettingView.setText("music: " + translateStateToText(MyGdxGame.audioManager.isMusicOn));
            }
            if (soundSettingView.isHit(myGdxGame.touch.x, myGdxGame.touch.y)) {
                boolean newState = !MemoryManager.loadIsSoundOn();
                MemoryManager.saveSoundSettings(newState);
                MyGdxGame.audioManager.isSoundOn = newState;
                if (newState) MyGdxGame.audioManager.BtnClick.play();
                soundSettingView.setText("sound: " + translateStateToText(newState));
            }
        }
    }

    private String translateStateToText(boolean state) {
        return state ? "ON" : "OFF";
    }
}