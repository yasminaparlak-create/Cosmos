package com.mygdx.game;

import com.badlogic.gdx.utils.TimeUtils;
import com.mygdx.game.managers.MemoryManager;
import java.util.ArrayList;

public class GameSession {
    public GameState state;

    // Таймеры
    long sessionStartTime;
    long pauseStartTime;
    private long lastTimeScoreUpdate;
    private float timeSinceLastSpawn = 0f;

    public int score = 0;
    int destructedTrashNumber;

    // Прогрессия сложности
    private float elapsedTimeSeconds = 0f;
    private float difficultyMultiplier = 1.0f;
    private static final float DIFFICULTY_GROWTH_RATE = 0.15f;
    private static final float MAX_DIFFICULTY_MULTIPLIER = 2.5f;

    public GameSession() {}

    public void startGame() {
        state = GameState.PLAYING;
        score = 0;
        destructedTrashNumber = 0;
        elapsedTimeSeconds = 0f;
        difficultyMultiplier = 1.0f;
        timeSinceLastSpawn = 0f;

        sessionStartTime = TimeUtils.millis();
        lastTimeScoreUpdate = sessionStartTime;
    }

    public void pauseGame() {
        state = GameState.PAUSED;
        pauseStartTime = TimeUtils.millis();
    }

    public void resumeGame() {
        state = GameState.PLAYING;
        long pauseDuration = TimeUtils.millis() - pauseStartTime;
        sessionStartTime += pauseDuration;
        lastTimeScoreUpdate += pauseDuration;
    }

    public void endGame() {
        updateScore();
        state = GameState.ENDED;

        ArrayList<Integer> recordsTable = MemoryManager.loadRecordsTable();
        int foundIdx = 0;
        for (; foundIdx < recordsTable.size(); foundIdx++) {
            if (recordsTable.get(foundIdx) < score) break;
        }
        recordsTable.add(foundIdx, score);

        while (recordsTable.size() > 5) {
            recordsTable.remove(recordsTable.size() - 1);
        }

        MemoryManager.saveTableOfRecords(recordsTable);
    }

    public void destructionRegistration() {
        destructedTrashNumber += 1;
    }


    public boolean shouldSpawnTrash() {
        float currentCooldown = GameSettings.STARTING_TRASH_APPEARANCE_COOL_DOWN * getSpawnCooldownMultiplier();

        if (timeSinceLastSpawn >= currentCooldown) {
            timeSinceLastSpawn = 0f;
            return true;
        }
        return false;
    }

    public void update(float delta) {
        if (state == GameState.PLAYING) {
            elapsedTimeSeconds += delta;
            timeSinceLastSpawn += delta;

            // Пересчёт сложности
            difficultyMultiplier = 1.0f + (DIFFICULTY_GROWTH_RATE * (elapsedTimeSeconds / 30f));
            if (difficultyMultiplier > MAX_DIFFICULTY_MULTIPLIER) {
                difficultyMultiplier = MAX_DIFFICULTY_MULTIPLIER;
            }
        }
    }

    public float getSpawnCooldownMultiplier() {
        return 1.0f / Math.max(1.0f, difficultyMultiplier); // Защита от деления на 0
    }

    public float getTrashSpeedMultiplier() {
        return difficultyMultiplier;
    }

    public float getDifficultyMultiplier() {
        return difficultyMultiplier;
    }


    public void addScore(int points) {
        score += points;
    }

    public void updateScore() {
        if (state == GameState.PLAYING) {
            long now = TimeUtils.millis();
            long timeDiff = now - lastTimeScoreUpdate;
            if (timeDiff >= 100) {
                int timePoints = (int) (timeDiff / 100);
                score += timePoints;
                lastTimeScoreUpdate += timePoints * 100L;
            }
        }
    }

    public int getScore() {
        return score;
    }
}