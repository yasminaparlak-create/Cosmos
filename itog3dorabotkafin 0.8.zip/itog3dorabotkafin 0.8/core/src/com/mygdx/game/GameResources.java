package com.mygdx.game;

import static com.badlogic.gdx.math.MathUtils.random;

import com.badlogic.gdx.graphics.Texture;

public class GameResources {

    //  Фоны и затемнения
    public static final String BACKGROUND_IMG_PATH = "textures/background.png";
    public static final String BLACKOUT_FULL_IMG_PATH = "textures/blackout_full.png";
    public static final String BLACKOUT_TOP_IMG_PATH = "textures/blackout_top.png";
    public static final String BLACKOUT_MIDDLE_IMG_PATH = "textures/blackout_middle.png";
    public static final String BLACKOUT_SC_IMG_PATH = "textures/sc1.png";

    //  Интерфейс и кнопки
    public static final String BUTTON_LONG_BG_IMG_PATH = "textures/btn_long.png";
    public static final String PAUSE_IMG_PATH = "textures/btn_pause.png";
    public static final String LIVE_IMG_PATH = "textures/heart3.png";

    // Игровые объекты
    public static String SHIP_IMG_PATH = "textures/ship1.png";
    public static final String BULLET_IMG_PATH = "textures/lazer.png";
    public static final String SHIELD_EFFECT_PATH = "textures/shield_effect2.png";
    //  Аудио
    public static final String BACKGROUND_MUSIC_PATH = "sounds/background_music.ogg";
    public static final String DESTROY_SOUND_PATH = "sounds/heavy-hit.mp3";
    public static final String DESTROY_SHIP_SOUND_PATH = "sounds/heavy-hit.mp3";
    public static final String SHOOT_SOUND_PATH = "sounds/shoot.mp3";
    public static final String CLICK_SOUND_PATH = "sounds/click_sound.wav";

    // Шрифты
    public static final String FONT_PATH = "fonts/Montserrat.ttf";

    //  Утилиты
    public static String getRandomTexturePath() {
        return switch (random.nextInt(5)) {
            case 0 -> "textures/sputnik1.png";
            case 1 -> "textures/sputnik2.png";
            case 2 -> "textures/sputnik3.png";
            case 3 -> "textures/meteorMax.png";
            default -> "textures/meteorMin.png";
        };
    }
    // Баффы и лут
    public static final String LOOT_RAPID_FIRE_PATH = "textures/loot_rapid_fire2.png";
    public static final String LOOT_SHIELD_PATH = "textures/loot_shield2.png";
    public static final String LOOT_EXTRA_LIFE_PATH = "textures/loot_extra_life2.png";
    public static final String LOOT_SCORE_BOOST_PATH = "textures/loot_score_boost2.png";

    public static Texture shieldEffectTexture;


}