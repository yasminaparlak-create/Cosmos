package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.Box2D;
import com.badlogic.gdx.physics.box2d.World;

import com.mygdx.game.managers.AudioManager;
import com.mygdx.game.managers.MemoryManager;
import com.mygdx.game.screens.GameScreen;
import com.mygdx.game.screens.MenuScreen;
import com.mygdx.game.screens.SettingsScreen;
import com.mygdx.game.screens.SkinScreen;

import static com.mygdx.game.GameSettings.*;

public class MyGdxGame extends Game {

    public World world;
    private float accumulator = 0;

    public SpriteBatch batch;
    public OrthographicCamera camera;
    public Vector3 touch;

    public BitmapFont largeWhiteFont;
    public BitmapFont commonWhiteFont;
    public BitmapFont commonBlackFont;
    public BitmapFont smallFont;

    public static AudioManager audioManager;

    public MenuScreen menuScreen;
    public GameScreen gameScreen;
    public SettingsScreen settingsScreen;
    public SkinScreen skinScreen;

    @Override
    public void create() {

        Box2D.init();
        world = new World(new Vector2(0, 0), true);


        largeWhiteFont = FontBuilder.generate(55, Color.WHITE, GameResources.FONT_PATH);
        commonWhiteFont = FontBuilder.generate(50, Color.WHITE, GameResources.FONT_PATH);
        commonBlackFont = FontBuilder.generate(35, Color.BLACK, GameResources.FONT_PATH);

        smallFont = FontBuilder.generate(35, Color.WHITE, GameResources.FONT_PATH);
        smallFont.getData().setScale(0.9f);

        batch = new SpriteBatch();
        camera = new OrthographicCamera();
        camera.setToOrtho(false, SCREEN_WIDTH, SCREEN_HEIGHT);
        touch = new Vector3();

        audioManager = new AudioManager();

        if (GameResources.shieldEffectTexture == null) {
            GameResources.shieldEffectTexture = new Texture(Gdx.files.internal(GameResources.SHIELD_EFFECT_PATH));
        }

        GameResources.SHIP_IMG_PATH = MemoryManager.loadShipImagePath();


        menuScreen = new MenuScreen(this);
        settingsScreen = new SettingsScreen(this);
        skinScreen = new SkinScreen(this);
        gameScreen = new GameScreen(this);

        setScreen(menuScreen);
    }

    @Override
    public void render() {

        super.render();
    }

    @Override
    public void dispose() {
        // Графика
        if (batch != null) batch.dispose();

        // Шрифты
        if (largeWhiteFont != null) largeWhiteFont.dispose();
        if (commonWhiteFont != null) commonWhiteFont.dispose();
        if (commonBlackFont != null) commonBlackFont.dispose();
        if (smallFont != null) smallFont.dispose();

        //  Физика
        if (world != null) world.dispose();

        //  Аудио
        if (audioManager != null) audioManager.dispose();

        //  Текстура щита
        if (GameResources.shieldEffectTexture != null) {
            GameResources.shieldEffectTexture.dispose();
            GameResources.shieldEffectTexture = null;
        }
    }

    public void stepWorld() {
        float delta = Gdx.graphics.getDeltaTime();
        accumulator += Math.min(delta, 0.25f);

        while (accumulator >= STEP_TIME) {
            world.step(STEP_TIME, VELOCITY_ITERATIONS, POSITION_ITERATIONS);
            accumulator -= STEP_TIME;
        }
    }
}